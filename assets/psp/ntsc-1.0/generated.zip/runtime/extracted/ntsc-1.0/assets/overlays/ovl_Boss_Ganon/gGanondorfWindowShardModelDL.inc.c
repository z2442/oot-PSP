    gsSPVertex(&gGanondorfWindowShardModelVtx[0], 0, 0),
    gsSP1Triangle(0, 0, 0, 0),
    gsSPEndDisplayList(),
