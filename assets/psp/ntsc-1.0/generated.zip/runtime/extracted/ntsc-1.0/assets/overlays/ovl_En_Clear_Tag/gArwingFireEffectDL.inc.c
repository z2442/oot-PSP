    gsSPDisplayList(0),
    gsSPVertex(&gArwingFireEffectVtx[0], 0, 0),
    gsSP1Triangle(0, 0, 0, 0),
    gsSPEndDisplayList(),
