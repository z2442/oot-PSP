    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0, 0, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gMantTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, gMantTex_WIDTH, gMantTex_HEIGHT, 0, G_TX_MIRROR |
 G_TX_WRAP, G_TX_NOMIRROR | G_TX_CLAMP, 0, 0, G_TX_NOLOD, G_TX_NOLOD),
    gsSPEndDisplayList(),
