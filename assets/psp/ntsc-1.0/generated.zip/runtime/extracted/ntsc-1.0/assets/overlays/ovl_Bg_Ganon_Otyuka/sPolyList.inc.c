    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(-0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(-0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(-0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(-0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        -0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        0, // dist
    }, // 0
    {
        0, // type
        {
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
            COLPOLY_VTX(0, 0), // 0
        }, // vtxData
        {
            COLPOLY_SNORMAL(0), // x
            COLPOLY_SNORMAL(0), // y
            COLPOLY_SNORMAL(0), // z
        }, // normal
        0, // dist
    }, // 0

