    gsSPVertex(&gGanonLightOrbModelVtx[0], 0, 0),
    gsSP2Triangles(0, 0, 0, 0, 0, 0, 0, 0),
    gsSPEndDisplayList(),
