#include "ovl_Demo_Shd.h"

#include "gfx.h"
#include "sys_matrix.h"

u64 ovl_Demo_Shd_00000000_Tex[TEX_LEN(u64, ovl_Demo_Shd_00000000_Tex_WIDTH, ovl_Demo_Shd_00000000_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Demo_Shd/ovl_Demo_Shd_00000000_Tex.i8.inc.c"
};

u64 ovl_Demo_Shd_00000800_Tex[TEX_LEN(u64, ovl_Demo_Shd_00000800_Tex_WIDTH, ovl_Demo_Shd_00000800_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Demo_Shd/ovl_Demo_Shd_00000800_Tex.i8.inc.c"
};

static Vtx ovl_Demo_Shd_Vtx_001000[93] = {
#include "assets/overlays/ovl_Demo_Shd/ovl_Demo_Shd_Vtx_001000.inc.c"
};

static Vtx ovl_Demo_Shd_Vtx_0015D0[104] = {
#include "assets/overlays/ovl_Demo_Shd/ovl_Demo_Shd_Vtx_0015D0.inc.c"
};

static Gfx D_809932D0[24] = {
#include "assets/overlays/ovl_Demo_Shd/D_809932D0.inc.c"
};

static Gfx D_80993390[37] = {
#include "assets/overlays/ovl_Demo_Shd/D_80993390.inc.c"
};

static Gfx D_809934B8[41] = {
#include "assets/overlays/ovl_Demo_Shd/D_809934B8.inc.c"
};

