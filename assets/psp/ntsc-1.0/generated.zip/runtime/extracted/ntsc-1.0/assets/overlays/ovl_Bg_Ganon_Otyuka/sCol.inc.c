    {
        -0, // x
        -0, // y
        -0, // z
    }, // minBounds
    {
        0, // x
        0, // y
        0, // z
    }, // maxBounds
    ARRAY_COUNT(sVtxList), // numVertices
    sVtxList, // vtxList
    ARRAY_COUNT(sPolyList), // numPolygons
    sPolyList, // polyList
    sSurfaceTypes, // surfaceTypeList
    sBgCamList, // bgCamList
    0, // numWaterBoxes
    NULL, // waterBoxes

