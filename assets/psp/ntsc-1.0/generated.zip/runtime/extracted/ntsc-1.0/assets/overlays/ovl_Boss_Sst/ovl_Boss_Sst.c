#include "ovl_Boss_Sst.h"

#include "gfx.h"
#include "sys_matrix.h"

static Gfx sBodyStaticDL[3] = {
#include "assets/overlays/ovl_Boss_Sst/sBodyStaticDL.inc.c"
};

static Gfx sHandTrailDL[4] = {
#include "assets/overlays/ovl_Boss_Sst/sHandTrailDL.inc.c"
};

static Vtx sIntroVanishVtx[4] = {
#include "assets/overlays/ovl_Boss_Sst/sIntroVanishVtx.inc.c"
};

u64 ovl_Boss_Sst_00000078_Tex[TEX_LEN(u64, ovl_Boss_Sst_00000078_Tex_WIDTH, ovl_Boss_Sst_00000078_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Sst/ovl_Boss_Sst_00000078_Tex.i8.inc.c"
};

static Gfx sIntroVanishDL[17] = {
#include "assets/overlays/ovl_Boss_Sst/sIntroVanishDL.inc.c"
};

static Vtx sShadowVtx[3] = {
#include "assets/overlays/ovl_Boss_Sst/sShadowVtx.inc.c"
};

u64 ovl_Boss_Sst_00000530_Tex[TEX_LEN(u64, ovl_Boss_Sst_00000530_Tex_WIDTH, ovl_Boss_Sst_00000530_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Sst/ovl_Boss_Sst_00000530_Tex.i8.inc.c"
};

static Gfx sShadowDL[16] = {
#include "assets/overlays/ovl_Boss_Sst/sShadowDL.inc.c"
};

