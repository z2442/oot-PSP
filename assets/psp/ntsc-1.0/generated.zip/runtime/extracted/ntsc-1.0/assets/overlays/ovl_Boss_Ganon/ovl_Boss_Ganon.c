#include "ovl_Boss_Ganon.h"
#include "assets/objects/gameplay_keep/gameplay_keep.h"

#include "gfx.h"
#include "sys_matrix.h"

static Vtx gGanondorfShadowModelVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShadowModelVtx.inc.c"
};

static Gfx gGanondorfShadowSetupDL[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShadowSetupDL.inc.c"
};

static Gfx gGanondorfShadowModelDL[6] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShadowModelDL.inc.c"
};

u64 ovl_Boss_Ganon_00000090_Tex[TEX_LEN(u64, ovl_Boss_Ganon_00000090_Tex_WIDTH, ovl_Boss_Ganon_00000090_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_00000090_Tex.i8.inc.c"
};

static Vtx gGanondorfTriforceVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfTriforceVtx.inc.c"
};

static Gfx gGanondorfTriforceDL[16] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfTriforceDL.inc.c"
};

u64 ovl_Boss_Ganon_00001150_TLUT[] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_00001190_CITex.tlut.rgba16.inc.c"
};

u64 ovl_Boss_Ganon_00001190_CITex[TEX_LEN(u64, ovl_Boss_Ganon_00001190_CITex_WIDTH, ovl_Boss_Ganon_00001190_CITex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_00001190_CITex.ci8.inc.c"
};

static Vtx gGanondorfWindowShardModelVtx[3] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfWindowShardModelVtx.inc.c"
};

static Gfx gGanondorfWindowShardMaterialDL[21] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfWindowShardMaterialDL.inc.c"
};

static Gfx gGanondorfWindowShardModelDL[3] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfWindowShardModelDL.inc.c"
};

static u64 gGanondorfWindowShatterTemplateTex[TEX_LEN(u64, gGanondorfWindowShatterTemplateTex_WIDTH, gGanondorfWindowShatterTemplateTex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfWindowShatterTemplateTex.i8.inc.c"
};

u64 ovl_Boss_Ganon_00001E80_Tex[TEX_LEN(u64, ovl_Boss_Ganon_00001E80_Tex_WIDTH, ovl_Boss_Ganon_00001E80_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_00001E80_Tex.i8.inc.c"
};

static Vtx gGanondorfSquareVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfSquareVtx.inc.c"
};

static Gfx gGanondorfLightBallMaterialDL[14] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightBallMaterialDL.inc.c"
};

static Gfx gGanondorfSquareDL[3] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfSquareDL.inc.c"
};

static u64 gGanondorfLightning1Tex[TEX_LEN(u64, gGanondorfLightning1Tex_WIDTH, gGanondorfLightning1Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning1Tex.i8.inc.c"
};

static u64 gGanondorfLightning2Tex[TEX_LEN(u64, gGanondorfLightning2Tex_WIDTH, gGanondorfLightning2Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning2Tex.i8.inc.c"
};

static u64 gGanondorfLightning3Tex[TEX_LEN(u64, gGanondorfLightning3Tex_WIDTH, gGanondorfLightning3Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning3Tex.i8.inc.c"
};

static u64 gGanondorfLightning4Tex[TEX_LEN(u64, gGanondorfLightning4Tex_WIDTH, gGanondorfLightning4Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning4Tex.i8.inc.c"
};

static u64 gGanondorfLightning5Tex[TEX_LEN(u64, gGanondorfLightning5Tex_WIDTH, gGanondorfLightning5Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning5Tex.i8.inc.c"
};

static u64 gGanondorfLightning6Tex[TEX_LEN(u64, gGanondorfLightning6Tex_WIDTH, gGanondorfLightning6Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning6Tex.i8.inc.c"
};

static u64 gGanondorfLightning7Tex[TEX_LEN(u64, gGanondorfLightning7Tex_WIDTH, gGanondorfLightning7Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning7Tex.i8.inc.c"
};

static u64 gGanondorfLightning8Tex[TEX_LEN(u64, gGanondorfLightning8Tex_WIDTH, gGanondorfLightning8Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning8Tex.i8.inc.c"
};

static u64 gGanondorfLightning9Tex[TEX_LEN(u64, gGanondorfLightning9Tex_WIDTH, gGanondorfLightning9Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning9Tex.i8.inc.c"
};

static u64 gGanondorfLightning10Tex[TEX_LEN(u64, gGanondorfLightning10Tex_WIDTH, gGanondorfLightning10Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning10Tex.i8.inc.c"
};

static u64 gGanondorfLightning11Tex[TEX_LEN(u64, gGanondorfLightning11Tex_WIDTH, gGanondorfLightning11Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning11Tex.i8.inc.c"
};

static u64 gGanondorfLightning12Tex[TEX_LEN(u64, gGanondorfLightning12Tex_WIDTH, gGanondorfLightning12Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightning12Tex.i8.inc.c"
};

static Vtx gGanondorfLightningVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightningVtx.inc.c"
};

static Gfx gGanondorfLightningDL[16] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightningDL.inc.c"
};

static Vtx gGanondorfUnusedVtx[3] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfUnusedVtx.inc.c"
};

static Gfx gGanondorfUnusedDL[9] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfUnusedDL.inc.c"
};

static Vtx gGanondorfLightRayTriVtx[3] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightRayTriVtx.inc.c"
};

static Gfx gGanondorfLightRayTriDL[9] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightRayTriDL.inc.c"
};

u64 ovl_Boss_Ganon_0000C0F8_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000C0F8_Tex_WIDTH, ovl_Boss_Ganon_0000C0F8_Tex_HEIGHT, 16)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000C0F8_Tex.ia16.inc.c"
};

u64 ovl_Boss_Ganon_0000C8F8_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000C8F8_Tex_WIDTH, ovl_Boss_Ganon_0000C8F8_Tex_HEIGHT, 4)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000C8F8_Tex.i4.inc.c"
};

u64 ovl_Boss_Ganon_0000D0F8_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000D0F8_Tex_WIDTH, ovl_Boss_Ganon_0000D0F8_Tex_HEIGHT, 4)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000D0F8_Tex.i4.inc.c"
};

static Vtx gGanondorfLightFlecksVtx[25] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightFlecksVtx.inc.c"
};

static Vtx gGanondorfBigMagicBGCircleVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfBigMagicBGCircleVtx.inc.c"
};

static Vtx gGanondorfDotVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfDotVtx.inc.c"
};

static Gfx gGanondorfLightFlecksDL[30] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightFlecksDL.inc.c"
};

static Gfx gGanondorfBigMagicBGCircleDL[21] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfBigMagicBGCircleDL.inc.c"
};

static Gfx gGanondorfDotDL[25] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfDotDL.inc.c"
};

u64 ovl_Boss_Ganon_0000DD68_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000DD68_Tex_WIDTH, ovl_Boss_Ganon_0000DD68_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000DD68_Tex.i8.inc.c"
};

static Vtx gGanondorfShockwaveVtx[26] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShockwaveVtx.inc.c"
};

static Gfx gGanondorfShockwaveDL[31] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShockwaveDL.inc.c"
};

u64 ovl_Boss_Ganon_0000E800_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000E800_Tex_WIDTH, ovl_Boss_Ganon_0000E800_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000E800_Tex.i8.inc.c"
};

u64 ovl_Boss_Ganon_0000F000_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000F000_Tex_WIDTH, ovl_Boss_Ganon_0000F000_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000F000_Tex.i8.inc.c"
};

static Vtx gGanondorfImpactVtx[26] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfImpactVtx.inc.c"
};

static Gfx gGanondorfImpactDarkDL[35] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfImpactDarkDL.inc.c"
};

static Gfx gGanondorfImpactLightDL[35] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfImpactLightDL.inc.c"
};

u64 ovl_Boss_Ganon_0000F7D0_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000F7D0_Tex_WIDTH, ovl_Boss_Ganon_0000F7D0_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000F7D0_Tex.i8.inc.c"
};

u64 ovl_Boss_Ganon_0000FFD0_Tex[TEX_LEN(u64, ovl_Boss_Ganon_0000FFD0_Tex_WIDTH, ovl_Boss_Ganon_0000FFD0_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_0000FFD0_Tex.i8.inc.c"
};

static Vtx gGanondorfShockGlowVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShockGlowVtx.inc.c"
};

static Gfx gGanondorfShockGlowDL[25] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShockGlowDL.inc.c"
};

u64 ovl_Boss_Ganon_000108D8_Tex[TEX_LEN(u64, ovl_Boss_Ganon_000108D8_Tex_WIDTH, ovl_Boss_Ganon_000108D8_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_000108D8_Tex.i8.inc.c"
};

static Vtx gGanondorfLightStreak1Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak1Vtx.inc.c"
};

static Vtx gGanondorfLightStreak2Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak2Vtx.inc.c"
};

static Vtx gGanondorfLightStreak3Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak3Vtx.inc.c"
};

static Vtx gGanondorfLightStreak4Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak4Vtx.inc.c"
};

static Vtx gGanondorfLightStreak5Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak5Vtx.inc.c"
};

static Vtx gGanondorfLightStreak6Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak6Vtx.inc.c"
};

static Vtx gGanondorfLightStreak7Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak7Vtx.inc.c"
};

static Vtx gGanondorfLightStreak8Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak8Vtx.inc.c"
};

static Vtx gGanondorfLightStreak9Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak9Vtx.inc.c"
};

static Vtx gGanondorfLightStreak10Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak10Vtx.inc.c"
};

static Vtx gGanondorfLightStreak11Vtx[10] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak11Vtx.inc.c"
};

static Vtx gGanondorfLightStreak12Vtx[8] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak12Vtx.inc.c"
};

static Gfx gGanondorfLightStreak1DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak1DL.inc.c"
};

static Gfx gGanondorfLightStreak2DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak2DL.inc.c"
};

static Gfx gGanondorfLightStreak3DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak3DL.inc.c"
};

static Gfx gGanondorfLightStreak4DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak4DL.inc.c"
};

static Gfx gGanondorfLightStreak5DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak5DL.inc.c"
};

static Gfx gGanondorfLightStreak6DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak6DL.inc.c"
};

static Gfx gGanondorfLightStreak7DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak7DL.inc.c"
};

static Gfx gGanondorfLightStreak8DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak8DL.inc.c"
};

static Gfx gGanondorfLightStreak9DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak9DL.inc.c"
};

static Gfx gGanondorfLightStreak10DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak10DL.inc.c"
};

static Gfx gGanondorfLightStreak11DL[7] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak11DL.inc.c"
};

static Gfx gGanondorfLightStreak12DL[20] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightStreak12DL.inc.c"
};

u64 ovl_Boss_Ganon_00011940_Tex[TEX_LEN(u64, ovl_Boss_Ganon_00011940_Tex_WIDTH, ovl_Boss_Ganon_00011940_Tex_HEIGHT, 4)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_00011940_Tex.i4.inc.c"
};

static Vtx gGanondorfLightCoreVtx[3] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightCoreVtx.inc.c"
};

static Gfx gGanondorfLightCoreDL[17] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfLightCoreDL.inc.c"
};

static Vtx gGanondorfShockVtx[4] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShockVtx.inc.c"
};

static Gfx gGanondorfShockDL[16] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfShockDL.inc.c"
};

u64 ovl_Boss_Ganon_00011CB8_Tex[TEX_LEN(u64, ovl_Boss_Ganon_00011CB8_Tex_WIDTH, ovl_Boss_Ganon_00011CB8_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_00011CB8_Tex.i8.inc.c"
};

u64 ovl_Boss_Ganon_000120B8_Tex[TEX_LEN(u64, ovl_Boss_Ganon_000120B8_Tex_WIDTH, ovl_Boss_Ganon_000120B8_Tex_HEIGHT, 8)] = {
#include "assets/overlays/ovl_Boss_Ganon/ovl_Boss_Ganon_000120B8_Tex.i8.inc.c"
};

static Vtx gGanondorfVortexVtx[22] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfVortexVtx.inc.c"
};

static Gfx gGanondorfVortexDL[33] = {
#include "assets/overlays/ovl_Boss_Ganon/gGanondorfVortexDL.inc.c"
};

