#ifndef OBJECT_HAKA_OBJECTS_H
#define OBJECT_HAKA_OBJECTS_H

#include "bgcheck.h"
#include "tex_len.h"
#include "ultra64.h"
#include "z_math.h"

extern Vtx gShadowTempleMetalGateVtx[];
extern Gfx gShadowTempleMetalGateDL[18];
extern BgCamInfo gShadowTempleMetalGateBgCamList[];
extern SurfaceType gShadowTempleMetalGateSurfaceTypes[];
extern CollisionPoly gShadowTempleMetalGatePolyList[];
extern Vec3s gShadowTempleMetalGateVtxList[];
extern CollisionHeader gShadowTempleMetalGateCol;
extern Vtx gShadowTempleRoom3HiddenPlatformsVtx[];
extern Gfx gShadowTempleRoom3HiddenPlatformsDL[102];
extern Vtx gShadowTempleRoom9HiddenPlatformsVtx[];
extern Gfx gShadowTempleRoom9HiddenPlatformsDL[63];
extern Vtx gShadowTempleRoom11HiddenObjectsVtx[];
extern Gfx gShadowTempleRoom11HiddenObjectsDL[132];
extern Vtx gShadowTempleRoom15HiddenWallsVtx[];
extern Gfx gShadowTempleRoom15HiddenWallsDL[79];
extern Vtx gShadowTempleFakeCryptWallGlowingSkullVtx[];
extern Gfx gShadowTempleFakeCryptWallGlowingSkullDL[55];
extern BgCamInfo gShadowTempleFakeCryptWallGlowingSkullBgCamList[];
extern SurfaceType gShadowTempleFakeCryptWallGlowingSkullSurfaceTypes[];
extern CollisionPoly gShadowTempleFakeCryptWallGlowingSkullPolyList[];
extern Vec3s gShadowTempleFakeCryptWallGlowingSkullVtxList[];
extern CollisionHeader gShadowTempleFakeCryptWallGlowingSkullCol;
extern Vtx gShadowTempleFakeWallStrangeFaceVtx[];
extern Gfx gShadowTempleFakeWallStrangeFaceDL[19];
extern BgCamInfo gShadowTempleFakeWallStrangeFaceBgCamList[];
extern SurfaceType gShadowTempleFakeWallStrangeFaceSurfaceTypes[];
extern CollisionPoly gShadowTempleFakeWallStrangeFacePolyList[];
extern Vec3s gShadowTempleFakeWallStrangeFaceVtxList[];
extern CollisionHeader gShadowTempleFakeWallStrangeFaceCol;
extern Vtx gShadowTempleRoom5FakeWallsVtx[];
extern Gfx gShadowTempleRoom5FakeWallsDL[29];
extern BgCamInfo gShadowTempleRoom5FakeWallsBgCamList[];
extern SurfaceType gShadowTempleRoom5FakeWallsSurfaceTypes[];
extern CollisionPoly gShadowTempleRoom5FakeWallsPolyList[];
extern Vec3s gShadowTempleRoom5FakeWallsVtxList[];
extern CollisionHeader gShadowTempleRoom5FakeWallsCol;
extern Vtx gShadowTempleRoom6FakeFloorVtx[];
extern Gfx gShadowTempleRoom6FakeFloorDL[26];
extern BgCamInfo gShadowTempleRoom6FakeFloorBgCamList[];
extern SurfaceType gShadowTempleRoom6FakeFloorSurfaceTypes[];
extern CollisionPoly gShadowTempleRoom6FakeFloorPolyList[];
extern Vec3s gShadowTempleRoom6FakeFloorVtxList[];
extern CollisionHeader gShadowTempleRoom6FakeFloorCol;
extern Vtx gShadowTempleRoom10FakeWallVtx[];
extern Gfx gShadowTempleRoom10FakeWallDL[26];
extern BgCamInfo gShadowTempleRoom10FakeWallBgCamList[];
extern SurfaceType gShadowTempleRoom10FakeWallSurfaceTypes[];
extern CollisionPoly gShadowTempleRoom10FakeWallPolyList[];
extern Vec3s gShadowTempleRoom10FakeWallVtxList[];
extern CollisionHeader gShadowTempleRoom10FakeWallCol;
extern Vtx gShadowTempleRoom18FakeWallVtx[];
extern Gfx gShadowTempleRoom18FakeWallDL[26];
extern BgCamInfo gShadowTempleRoom18FakeWallBgCamList[];
extern SurfaceType gShadowTempleRoom18FakeWallSurfaceTypes[];
extern CollisionPoly gShadowTempleRoom18FakeWallPolyList[];
extern Vec3s gShadowTempleRoom18FakeWallVtxList[];
extern CollisionHeader gShadowTempleRoom18FakeWallCol;
extern Vtx gShadowTempleBlackPlatformWithScrewColumnVtx[];
extern Gfx gShadowTempleBlackPlatformWithScrewColumnDL[38];
extern BgCamInfo gShadowTempleBlackPlatformWithScrewColumnBgCamList[];
extern SurfaceType gShadowTempleBlackPlatformWithScrewColumnSurfaceTypes[];
extern CollisionPoly gShadowTempleBlackPlatformWithScrewColumnPolyList[];
extern Vec3s gShadowTempleBlackPlatformWithScrewColumnVtxList[];
extern CollisionHeader gShadowTempleBlackPlatformWithScrewColumnCol;
extern Vtx object_haka_objects_Vtx_005360[];
extern Gfx object_haka_objects_DL_005A70[67];
extern Vtx gShadowTempleSkullWallVtx[];
extern Gfx gShadowTempleSkullWallDL[27];
extern BgCamInfo gShadowTempleSkullWallBgCamList[];
extern SurfaceType gShadowTempleSkullWallSurfaceTypes[];
extern CollisionPoly gShadowTempleSkullWallPolyList[];
extern Vec3s gShadowTempleSkullWallVtxList[];
extern CollisionHeader gShadowTempleSkullWallCol;
extern Vtx gShadowTempleBirdStatueVtx[];
extern Gfx gShadowTempleBirdStatueDL[93];
extern BgCamInfo gShadowTempleBirdStatueBgCamList[];
extern SurfaceType gShadowTempleBirdStatueSurfaceTypes[];
extern CollisionPoly gShadowTempleBirdStatuePolyList[];
extern Vec3s gShadowTempleBirdStatueVtxList[];
extern CollisionHeader gShadowTempleBirdStatueCol;
extern Vtx gShadowTempleFanBladeVtx[];
extern Gfx gShadowTempleFanBladeDL[62];
extern Vtx gShadowTempleGuillotineVtx[];
extern Gfx gShadowTempleGuillotineDL[44];
extern Vtx gShadowTempleSpikedWallEastVtx[];
extern Gfx gShadowTempleSpikedWallEastDL[75];
extern BgCamInfo gShadowTempleSpikedWallEastBgCamList[];
extern SurfaceType gShadowTempleSpikedWallEastSurfaceTypes[];
extern CollisionPoly gShadowTempleSpikedWallEastPolyList[];
extern Vec3s gShadowTempleSpikedWallEastVtxList[];
extern CollisionHeader gShadowTempleSpikedWallEastCol;
extern Vtx gShadowTempleSpikedWallWestVtx[];
extern Gfx gShadowTempleSpikedWallWestDL[78];
extern BgCamInfo gShadowTempleSpikedWallWestBgCamList[];
extern SurfaceType gShadowTempleSpikedWallWestSurfaceTypes[];
extern CollisionPoly gShadowTempleSpikedWallWestPolyList[];
extern Vec3s gShadowTempleSpikedWallWestVtxList[];
extern CollisionHeader gShadowTempleSpikedWallWestCol;
extern Vtx gShadowTempleHiddenBlockPlatformVtx[];
extern Gfx gShadowTempleHiddenBlockPlatformDL[49];
extern BgCamInfo gShadowTempleHiddenBlockPlatformBgCamList[];
extern SurfaceType gShadowTempleHiddenBlockPlatformSurfaceTypes[];
extern CollisionPoly gShadowTempleHiddenBlockPlatformPolyList[];
extern Vec3s gShadowTempleHiddenBlockPlatformVtxList[];
extern CollisionHeader gShadowTempleHiddenBlockPlatformCol;
extern Vtx gShadowTempleSpikedCrusherVtx[];
extern Gfx gShadowTempleSpikedCrusherDL[76];
extern BgCamInfo gShadowTempleSpikedCrusherBgCamList[];
extern SurfaceType gShadowTempleSpikedCrusherSurfaceTypes[];
extern CollisionPoly gShadowTempleSpikedCrusherPolyList[];
extern Vec3s gShadowTempleSpikedCrusherVtxList[];
extern CollisionHeader gShadowTempleSpikedCrusherCol;
extern Vtx gShadowTempleChainedElevatorPlatformVtx[];
extern Gfx gShadowTempleChainedElevatorPlatformDL[88];
extern BgCamInfo gShadowTempleChainedElevatorPlatformBgCamList[];
extern SurfaceType gShadowTempleChainedElevatorPlatformSurfaceTypes[];
extern CollisionPoly gShadowTempleChainedElevatorPlatformPolyList[];
extern Vec3s gShadowTempleChainedElevatorPlatformVtxList[];
extern CollisionHeader gShadowTempleChainedElevatorPlatformCol;
extern Vtx object_haka_objects_Vtx_00A820[];
extern Gfx object_haka_objects_DL_00A860[18];
extern BgCamInfo object_haka_objects_Col_00A938_0600A8F0_BgCamList[];
extern SurfaceType object_haka_objects_Col_00A938_0600A8F8_SurfaceTypes[];
extern CollisionPoly object_haka_objects_Col_00A938_0600A900_PolyList[];
extern Vec3s object_haka_objects_Col_00A938_0600A920_VtxList[];
extern CollisionHeader object_haka_objects_Col_00A938;
extern Vtx object_haka_objects_Vtx_00A970[];
extern Gfx object_haka_objects_DL_00BF20[156];
extern Vtx object_haka_objects_Vtx_00C400[];
extern Gfx object_haka_objects_DL_00D330[235];
extern BgCamInfo object_haka_objects_Col_00E408_0600DA90_BgCamList[];
extern SurfaceType object_haka_objects_Col_00E408_0600DA98_SurfaceTypes[];
extern CollisionPoly object_haka_objects_Col_00E408_0600DAA0_PolyList[];
extern Vec3s object_haka_objects_Col_00E408_0600E240_VtxList[];
extern CollisionHeader object_haka_objects_Col_00E408;
extern Vtx object_haka_objects_Vtx_00E440[];
extern Gfx object_haka_objects_DL_00E910[38];
extern BgCamInfo object_haka_objects_Col_00ED7C_0600EA40_BgCamList[];
extern SurfaceType object_haka_objects_Col_00ED7C_0600EA48_SurfaceTypes[];
extern CollisionPoly object_haka_objects_Col_00ED7C_0600EA58_PolyList[];
extern Vec3s object_haka_objects_Col_00ED7C_0600EC98_VtxList[];
extern CollisionHeader object_haka_objects_Col_00ED7C;
extern Vtx object_haka_objects_Vtx_00EDB0[];
extern Gfx object_haka_objects_DL_00F1B0[66];
extern Vtx object_haka_objects_Vtx_00F3C0[];
extern Gfx object_haka_objects_DL_00FE40[101];
extern BgCamInfo object_haka_objects_Col_0108B8_06010170_BgCamList[];
extern SurfaceType object_haka_objects_Col_0108B8_06010178_SurfaceTypes[];
extern CollisionPoly object_haka_objects_Col_0108B8_06010180_PolyList[];
extern Vec3s object_haka_objects_Col_0108B8_06010780_VtxList[];
extern CollisionHeader object_haka_objects_Col_0108B8;
extern Vtx object_haka_objects_Vtx_0108F0[];
extern Gfx object_haka_objects_DL_010A10[28];
extern Vtx object_haka_objects_Vtx_010AF0[];
extern Gfx object_haka_objects_DL_010C10[28];
extern BgCamInfo object_haka_objects_Col_010E10_06010CF0_BgCamList[];
extern SurfaceType object_haka_objects_Col_010E10_06010CF8_SurfaceTypes[];
extern CollisionPoly object_haka_objects_Col_010E10_06010D00_PolyList[];
extern Vec3s object_haka_objects_Col_010E10_06010DC0_VtxList[];
extern CollisionHeader object_haka_objects_Col_010E10;
extern Vtx object_haka_objects_Vtx_010E40[];
extern Gfx object_haka_objects_DL_012270[262];
extern BgCamInfo object_haka_objects_Col_0131C4_06012AA0_BgCamList[];
extern SurfaceType object_haka_objects_Col_0131C4_06012AA8_SurfaceTypes[];
extern CollisionPoly object_haka_objects_Col_0131C4_06012AB8_PolyList[];
extern Vec3s object_haka_objects_Col_0131C4_06013048_VtxList[];
extern CollisionHeader object_haka_objects_Col_0131C4;
#define object_haka_objects_Tex_0131F0_WIDTH 32
#define object_haka_objects_Tex_0131F0_HEIGHT 32
extern u64 object_haka_objects_Tex_0131F0[TEX_LEN(u64, object_haka_objects_Tex_0131F0_WIDTH, object_haka_objects_Tex_0131F0_HEIGHT, 8)];
#define object_haka_objects_Tex_0135F0_WIDTH 32
#define object_haka_objects_Tex_0135F0_HEIGHT 32
extern u64 object_haka_objects_Tex_0135F0[TEX_LEN(u64, object_haka_objects_Tex_0135F0_WIDTH, object_haka_objects_Tex_0135F0_HEIGHT, 16)];
#define object_haka_objects_Tex_013DF0_WIDTH 32
#define object_haka_objects_Tex_013DF0_HEIGHT 32
extern u64 object_haka_objects_Tex_013DF0[TEX_LEN(u64, object_haka_objects_Tex_013DF0_WIDTH, object_haka_objects_Tex_013DF0_HEIGHT, 16)];
#define gShadowTempleCryptWallTex_WIDTH 32
#define gShadowTempleCryptWallTex_HEIGHT 64
extern u64 gShadowTempleCryptWallTex[TEX_LEN(u64, gShadowTempleCryptWallTex_WIDTH, gShadowTempleCryptWallTex_HEIGHT, 16)];
#define object_haka_objects_Tex_0155F0_WIDTH 32
#define object_haka_objects_Tex_0155F0_HEIGHT 64
extern u64 object_haka_objects_Tex_0155F0[TEX_LEN(u64, object_haka_objects_Tex_0155F0_WIDTH, object_haka_objects_Tex_0155F0_HEIGHT, 16)];
#define object_haka_objects_Tex_0165F0_WIDTH 32
#define object_haka_objects_Tex_0165F0_HEIGHT 8
extern u64 object_haka_objects_Tex_0165F0[TEX_LEN(u64, object_haka_objects_Tex_0165F0_WIDTH, object_haka_objects_Tex_0165F0_HEIGHT, 16)];
#define object_haka_objects_Tex_0167F0_WIDTH 32
#define object_haka_objects_Tex_0167F0_HEIGHT 16
extern u64 object_haka_objects_Tex_0167F0[TEX_LEN(u64, object_haka_objects_Tex_0167F0_WIDTH, object_haka_objects_Tex_0167F0_HEIGHT, 16)];
#define object_haka_objects_Tex_016BF0_WIDTH 32
#define object_haka_objects_Tex_016BF0_HEIGHT 32
extern u64 object_haka_objects_Tex_016BF0[TEX_LEN(u64, object_haka_objects_Tex_016BF0_WIDTH, object_haka_objects_Tex_016BF0_HEIGHT, 4)];
#define object_haka_objects_Tex_016DF0_WIDTH 32
#define object_haka_objects_Tex_016DF0_HEIGHT 32
extern u64 object_haka_objects_Tex_016DF0[TEX_LEN(u64, object_haka_objects_Tex_016DF0_WIDTH, object_haka_objects_Tex_016DF0_HEIGHT, 4)];
#define object_haka_objects_Tex_016FF0_WIDTH 32
#define object_haka_objects_Tex_016FF0_HEIGHT 32
extern u64 object_haka_objects_Tex_016FF0[TEX_LEN(u64, object_haka_objects_Tex_016FF0_WIDTH, object_haka_objects_Tex_016FF0_HEIGHT, 4)];
#define object_haka_objects_Tex_0171F0_WIDTH 32
#define object_haka_objects_Tex_0171F0_HEIGHT 32
extern u64 object_haka_objects_Tex_0171F0[TEX_LEN(u64, object_haka_objects_Tex_0171F0_WIDTH, object_haka_objects_Tex_0171F0_HEIGHT, 4)];
#define object_haka_objects_Tex_0173F0_WIDTH 32
#define object_haka_objects_Tex_0173F0_HEIGHT 32
extern u64 object_haka_objects_Tex_0173F0[TEX_LEN(u64, object_haka_objects_Tex_0173F0_WIDTH, object_haka_objects_Tex_0173F0_HEIGHT, 4)];
#define object_haka_objects_Tex_0175F0_WIDTH 32
#define object_haka_objects_Tex_0175F0_HEIGHT 32
extern u64 object_haka_objects_Tex_0175F0[TEX_LEN(u64, object_haka_objects_Tex_0175F0_WIDTH, object_haka_objects_Tex_0175F0_HEIGHT, 4)];
#define object_haka_objects_Tex_0177F0_WIDTH 32
#define object_haka_objects_Tex_0177F0_HEIGHT 32
extern u64 object_haka_objects_Tex_0177F0[TEX_LEN(u64, object_haka_objects_Tex_0177F0_WIDTH, object_haka_objects_Tex_0177F0_HEIGHT, 16)];
#define object_haka_objects_Tex_017FF0_WIDTH 32
#define object_haka_objects_Tex_017FF0_HEIGHT 32
extern u64 object_haka_objects_Tex_017FF0[TEX_LEN(u64, object_haka_objects_Tex_017FF0_WIDTH, object_haka_objects_Tex_017FF0_HEIGHT, 16)];
#define object_haka_objects_Tex_0187F0_WIDTH 16
#define object_haka_objects_Tex_0187F0_HEIGHT 64
extern u64 object_haka_objects_Tex_0187F0[TEX_LEN(u64, object_haka_objects_Tex_0187F0_WIDTH, object_haka_objects_Tex_0187F0_HEIGHT, 16)];
#define object_haka_objects_Tex_018FF0_WIDTH 32
#define object_haka_objects_Tex_018FF0_HEIGHT 32
extern u64 object_haka_objects_Tex_018FF0[TEX_LEN(u64, object_haka_objects_Tex_018FF0_WIDTH, object_haka_objects_Tex_018FF0_HEIGHT, 16)];
#define object_haka_objects_Tex_0197F0_WIDTH 16
#define object_haka_objects_Tex_0197F0_HEIGHT 16
extern u64 object_haka_objects_Tex_0197F0[TEX_LEN(u64, object_haka_objects_Tex_0197F0_WIDTH, object_haka_objects_Tex_0197F0_HEIGHT, 4)];
#define object_haka_objects_Tex_019870_WIDTH 32
#define object_haka_objects_Tex_019870_HEIGHT 32
extern u64 object_haka_objects_Tex_019870[TEX_LEN(u64, object_haka_objects_Tex_019870_WIDTH, object_haka_objects_Tex_019870_HEIGHT, 16)];
#define object_haka_objects_Tex_01A070_WIDTH 16
#define object_haka_objects_Tex_01A070_HEIGHT 32
extern u64 object_haka_objects_Tex_01A070[TEX_LEN(u64, object_haka_objects_Tex_01A070_WIDTH, object_haka_objects_Tex_01A070_HEIGHT, 16)];
#define object_haka_objects_Tex_01A470_WIDTH 32
#define object_haka_objects_Tex_01A470_HEIGHT 32
extern u64 object_haka_objects_Tex_01A470[TEX_LEN(u64, object_haka_objects_Tex_01A470_WIDTH, object_haka_objects_Tex_01A470_HEIGHT, 4)];
#define object_haka_objects_Tex_01A670_WIDTH 32
#define object_haka_objects_Tex_01A670_HEIGHT 32
extern u64 object_haka_objects_Tex_01A670[TEX_LEN(u64, object_haka_objects_Tex_01A670_WIDTH, object_haka_objects_Tex_01A670_HEIGHT, 16)];
#define object_haka_objects_Tex_01AE70_WIDTH 64
#define object_haka_objects_Tex_01AE70_HEIGHT 32
extern u64 object_haka_objects_Tex_01AE70[TEX_LEN(u64, object_haka_objects_Tex_01AE70_WIDTH, object_haka_objects_Tex_01AE70_HEIGHT, 4)];
#define object_haka_objects_Tex_01B270_WIDTH 64
#define object_haka_objects_Tex_01B270_HEIGHT 16
extern u64 object_haka_objects_Tex_01B270[TEX_LEN(u64, object_haka_objects_Tex_01B270_WIDTH, object_haka_objects_Tex_01B270_HEIGHT, 16)];
#define object_haka_objects_Tex_01BA70_WIDTH 64
#define object_haka_objects_Tex_01BA70_HEIGHT 16
extern u64 object_haka_objects_Tex_01BA70[TEX_LEN(u64, object_haka_objects_Tex_01BA70_WIDTH, object_haka_objects_Tex_01BA70_HEIGHT, 16)];
#define object_haka_objects_Tex_01C270_WIDTH 32
#define object_haka_objects_Tex_01C270_HEIGHT 32
extern u64 object_haka_objects_Tex_01C270[TEX_LEN(u64, object_haka_objects_Tex_01C270_WIDTH, object_haka_objects_Tex_01C270_HEIGHT, 4)];
#define object_haka_objects_Tex_01C470_WIDTH 32
#define object_haka_objects_Tex_01C470_HEIGHT 32
extern u64 object_haka_objects_Tex_01C470[TEX_LEN(u64, object_haka_objects_Tex_01C470_WIDTH, object_haka_objects_Tex_01C470_HEIGHT, 4)];
#define object_haka_objects_Tex_01C670_WIDTH 32
#define object_haka_objects_Tex_01C670_HEIGHT 33
extern u64 object_haka_objects_Tex_01C670[TEX_LEN(u64, object_haka_objects_Tex_01C670_WIDTH, object_haka_objects_Tex_01C670_HEIGHT, 16)];
#define object_haka_objects_Tex_01CEB0_WIDTH 64
#define object_haka_objects_Tex_01CEB0_HEIGHT 64
extern u64 object_haka_objects_Tex_01CEB0[TEX_LEN(u64, object_haka_objects_Tex_01CEB0_WIDTH, object_haka_objects_Tex_01CEB0_HEIGHT, 4)];

#endif
